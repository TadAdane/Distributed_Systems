package com.example.NamingServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
